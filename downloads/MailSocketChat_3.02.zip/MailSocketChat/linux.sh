#!/bin/sh
 BINDIR=$(dirname "$(readlink -fn "$0")")
 cd "$BINDIR"
 java -jar MailSocketChat.jar http:// 名前 GMailアドレス Gmailパスワード Normal Text